//file di sviluppo delle funzioni della classe
#include <iostream>
#include <cstring>
#include <ctime>
#include <cstdlib>
#include <cstdlib>
#include <fstream>
#include "briscola.h"
#define MAX_RAND 40
#define DIM_MAX 500

//fstream mazzoGioco, mazzoGiocatore, mazzoComputer;

Briscola::Briscola(void){
	punteggio_giocatore = 0;
	punteggio_computer = 0;
	for(int i=0; i < 3; i++){
		mazzo_giocatore[i].numero = 0;
		mazzo_giocatore[i].tipo = "nullo";
		mazzo_giocatore[i].presente = false;
		mazzo_computer[i].numero = 0;
		mazzo_computer[i].tipo = "nullo";
		mazzo_computer[i].presente = false;
	}
	for(int i=0; i < 40; i++){
		mazzo[i].numero = 0;
		mazzo[i].tipo = "nullo";
		mazzo[i].presente = false;
		mazzo[i].punteggio = 0;
	}
	tipo_dominante = "nullo";
}

void Briscola::setMazzo(void){
	int i=0, j=0;
	for(i=0; i < 40; i++){
		if(i < 10){
			mazzo[i].numero = j+1;
			mazzo[i].tipo = "coppe";
			mazzo[i].presente = true;
			j++;
			if(j == 10){
				j=0;
			}
		}
		//j = 0;
		if(i >= 10 && i < 20){
			mazzo[i].numero = j+1;
			mazzo[i].tipo = "spade";
			mazzo[i].presente = true;
			j++;
			if(j == 10){
				j=0;
			}
		}
		//j = 0;
		if(i >= 20 && i < 30){
			mazzo[i].numero = j+1;
			mazzo[i].tipo = "bastoni";
			mazzo[i].presente = true;
			j++;
			if(j == 10){
				j=0;
			}
		}
		//j = 0;
		if(i >= 30 && i < 40){
			mazzo[i].numero = j+1;
			mazzo[i].tipo = "denari";
			mazzo[i].presente = true;
			j++;
			if(j == 10){
				j=0;
			}
		}
		switch(mazzo[i].numero){
			case 1:
				mazzo[i].punteggio = 11;
				break;
			case 2:
				mazzo[i].punteggio = 0;
				break;
			case 3:
				mazzo[i].punteggio = 10;
				break;
			case 4:
				mazzo[i].punteggio = 0;
				break;
			case 5:
				mazzo[i].punteggio = 0;
				break;
			case 6:
				mazzo[i].punteggio = 0;
				break;
			case 7:
				mazzo[i].punteggio = 0;
				break;
			case 8:
				mazzo[i].punteggio = 2;
				break;
			case 9:
				mazzo[i].punteggio = 3;
				break;
			case 10:
				mazzo[i].punteggio = 4;
				break;
			default:
				break;
		}
	}
}

void Briscola::setMazzoGiocatore(void){
	int n_casuale=0;
	srand(time(NULL));
	for(int i=0; i < 3; i++){
		n_casuale = rand()%MAX_RAND + 1;
		if (mazzo[n_casuale].presente == false){ //si controlla che nel mazzo non ci sia una carta gi� usata.
			i--;
			continue;
		}
		else{
			mazzo_giocatore[i] = mazzo[n_casuale];
			mazzo[n_casuale].presente = false;
		}
	}
	
}

void Briscola::setMazzoComputer(void){
	int n_casuale=0;
	srand(time(NULL));
	for(int i=0; i < 3; i++){
		n_casuale = rand()%MAX_RAND + 1;
		if (mazzo[n_casuale].presente == false){ //si controlla che nel mazzo non ci sia una carta gi� usata.
			i--;
			continue;
		}
		else{
			mazzo_computer[i] = mazzo[n_casuale];
			mazzo[n_casuale].presente = false;
		}
	}
	
}

void Briscola::setDominante(void){
	int n_casuale = 0;
	srand(time(NULL));
	n_casuale = rand()%4+1;
	switch(n_casuale){
		case 1:
			tipo_dominante = "coppe";
			break;
		case 2:
			tipo_dominante = "spade";
			break;
		case 3: 
			tipo_dominante = "bastoni";
			break;
		case 4:
			tipo_dominante = "denari";
			break;
		default:
			break; 
	}
}

void Briscola::setPunteggioGiocatore(int n){
	punteggio_giocatore += n;
}

void Briscola::setPunteggioComputer(int n){
	punteggio_computer += n;
}

int Briscola::getPunteggioGiocatore(void){
	return punteggio_giocatore;
}

int Briscola::getPunteggioComputer(void){
	return punteggio_computer;
}

void Briscola::stampaDominante(void){
	cout<<"LA BRISCOLA E': "<<tipo_dominante<<"."<<endl;
}

void Briscola::stampaMazzoGiocatore(void){
	//cout<<"Le tue carte "<<endl; //per ora le stampiamo scritte poi se c'� tempo ascii art
	for(int i=0; i < 3; i++){
		//cout<<mazzo_giocatore[i].numero<<" "<<mazzo_giocatore[i].tipo<<endl;
		if(mazzo_giocatore[i].tipo == "bastoni"){
			switch(mazzo_giocatore[i].numero){
				case 1:
					cout<<" _____________"<<endl<<"|             |"<<endl<<"|     "<<"asso"<<"    |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
					break;
				case 8:
					cout<<" _____________"<<endl<<"|             |"<<endl<<"|    "<<"fante"<<"    |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
					break;
				case 9:
					cout<<" _____________"<<endl<<"|             |"<<endl<<"|   "<<"cavallo"<<"   |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
					break;
				case 10:
					cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<"re"<<"     |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
					break;
				default:
					cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<mazzo_giocatore[i].numero<<"      |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
					break;
			}
			
			//cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<mazzo_giocatore[i].numero<<"      |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|_____________|"<<endl;
		}
		else{
			if(mazzo_giocatore[i].tipo == "spade"){
				switch (mazzo_giocatore[i].numero){
					case 1:
						cout<<" _____________"<<endl<<"|             |"<<endl<<"|     "<<"asso"<<"    |"<<endl<<"|    spade    |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     |:|     |"<<endl<<"|   `--8--'   |"<<endl<<"|      8      |"<<endl<<"|      0      |"<<endl<<"|_____________|"<<endl;
						break;
					case 8:
						cout<<" _____________"<<endl<<"|             |"<<endl<<"|    "<<"fante"<<"    |"<<endl<<"|    spade    |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     |:|     |"<<endl<<"|   `--8--'   |"<<endl<<"|      8      |"<<endl<<"|      0      |"<<endl<<"|_____________|"<<endl;
						break;
					case 9:
						cout<<" _____________"<<endl<<"|             |"<<endl<<"|   "<<"cavallo"<<"   |"<<endl<<"|    spade    |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     |:|     |"<<endl<<"|   `--8--'   |"<<endl<<"|      8      |"<<endl<<"|      0      |"<<endl<<"|_____________|"<<endl;
						break;
					case 10:
						cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<"re"<<"     |"<<endl<<"|    spade    |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     |:|     |"<<endl<<"|   `--8--'   |"<<endl<<"|      8      |"<<endl<<"|      0      |"<<endl<<"|_____________|"<<endl;
						break;
					default:
						cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<mazzo_giocatore[i].numero<<"      |"<<endl<<"|    spade    |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     |:|     |"<<endl<<"|   `--8--'   |"<<endl<<"|      8      |"<<endl<<"|      0      |"<<endl<<"|_____________|"<<endl;
						break;
				}
			}
			else{
				if(mazzo_giocatore[i].tipo == "coppe"){
					switch(mazzo_giocatore[i].numero){
						case 1:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|     "<<"asso"<<"    |"<<endl<<"|    coppe    |"<<endl<<"|      _      |"<<endl<<"|     / \\     |"<<endl<<"|     \\ /     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     / \\     |"<<endl<<"|     \\_/     |"<<endl<<"|_____________|"<<endl;
							break;
						case 8:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|    "<<"fante"<<"    |"<<endl<<"|    coppe    |"<<endl<<"|      _      |"<<endl<<"|     / \\     |"<<endl<<"|     \\ /     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     / \\     |"<<endl<<"|     \\_/     |"<<endl<<"|_____________|"<<endl;
							break;
						case 9:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|   "<<"cavallo"<<"   |"<<endl<<"|    coppe    |"<<endl<<"|      _      |"<<endl<<"|     / \\     |"<<endl<<"|     \\ /     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     / \\     |"<<endl<<"|     \\_/     |"<<endl<<"|_____________|"<<endl;
							break;
						case 10:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<"re"<<"     |"<<endl<<"|    coppe    |"<<endl<<"|      _      |"<<endl<<"|     / \\     |"<<endl<<"|     \\ /     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     / \\     |"<<endl<<"|     \\_/     |"<<endl<<"|_____________|"<<endl;
							break;
						default:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<mazzo_giocatore[i].numero<<"      |"<<endl<<"|    coppe    |"<<endl<<"|      _      |"<<endl<<"|     / \\     |"<<endl<<"|     \\ /     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     / \\     |"<<endl<<"|     \\_/     |"<<endl<<"|_____________|"<<endl;
							break;
					}
				}
				else{
					switch(mazzo_giocatore[i].numero){
						case 1:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|     "<<"asso"<<"    |"<<endl<<"|    denari   |"<<endl<<"|             |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|_____________|"<<endl;
							break;
						case 8: 
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|    "<<"fante"<<"    |"<<endl<<"|    denari   |"<<endl<<"|             |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|_____________|"<<endl;
							break;
						case 9:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|   "<<"cavallo"<<"   |"<<endl<<"|    denari   |"<<endl<<"|             |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|_____________|"<<endl;
							break;
						case 10: 
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<"re"<<"     |"<<endl<<"|    denari   |"<<endl<<"|             |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|_____________|"<<endl;
							break;
						default:
							cout<<" _____________"<<endl<<"|             |"<<endl<<"|      "<<mazzo_giocatore[i].numero<<"      |"<<endl<<"|    denari   |"<<endl<<"|             |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|      O      |"<<endl<<"|_____________|"<<endl;
							break;
					}
				}
			}
		}
	}
	
	
}

void Briscola::stampaMazzoComputer(void){  //debug
	cout<<"Mazzo avversario: "<<endl;
	/*for(int i=0; i < 3; i++){
		cout<<mazzo_computer[i].numero<<" "<<mazzo_computer[i].tipo<<endl;
	}*/
	/*cout<<"________________"<<"\t________________"<<"\t________________"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|	       |"<<"\t|	       |"<<"\t|	       |"<<endl;
		cout<<"|______________|"<<"\t|______________|"<<"\t|______________|"<<endl;
*/}

int Briscola::lancioCartaComputer(void){
	int n_casuale=0;
	srand(time(NULL));
	n_casuale = rand()%3;
	while(mazzo_computer[n_casuale].presente == false){
		n_casuale = rand()%3;
	//	cout<<"questo e' un debug, numero casuale estratto "<<n_casuale<<endl;	
	}
	switch(mazzo_computer[n_casuale].numero){
		case 1:
			cout<<"Il tuo avversario ha tirato l'"<<"asso di "<<mazzo_computer[n_casuale].tipo<<"."<<endl; 
			break;
		case 8:
			cout<<"Il tuo avversario ha tirato il "<<"fante di "<<mazzo_computer[n_casuale].tipo<<"."<<endl;
			break;
		case 9:  
			cout<<"Il tuo avversario ha tirato il "<<"cavallo di "<<mazzo_computer[n_casuale].tipo<<"."<<endl;
			break;
		case 10:
			cout<<"Il tuo avversario ha tirato il "<<"re di "<<mazzo_computer[n_casuale].tipo<<"."<<endl;
			break;
		default:
			cout<<"Il tuo avversario ha tirato il "<<mazzo_computer[n_casuale].numero<<" di "<<mazzo_computer[n_casuale].tipo<<"."<<endl;
			break;
	}
	
	mazzo_computer[n_casuale].presente = false;
	return n_casuale;
	
}

void Briscola::lancioCartaGiocatore(int n){
	//cout<<"Hai tirato il "<<mazzo_giocatore[n-1].numero<<" "<<mazzo_giocatore[n-1].tipo<<"."<<endl;
	mazzo_giocatore[n-1].presente = false;
}

void Briscola::pescaCarta(void){ // funzione errata
	int n_casuale=0, n_casuale2=0;
	srand(time(NULL));
	
	do{
		n_casuale = rand()%MAX_RAND;
	}while(mazzo[n_casuale].presente == false);
	mazzo[n_casuale].presente = false; //debug
	
	do{
		n_casuale2 = rand()%MAX_RAND;
	}while(mazzo[n_casuale2].presente == false);
	mazzo[n_casuale2].presente = false;
	
	for(int i=0; i < 3; i++){
		if(mazzo_computer[i].presente == false){
			mazzo_computer[i] = mazzo[n_casuale2];
			mazzo_computer[i].presente = true;//debug
			//mazzo[n_casuale2].presente = false;
		}
	}
	for(int i=0; i < 3; i++){
		if(mazzo_giocatore[i].presente == false){
			mazzo_giocatore[i] = mazzo[n_casuale];
			mazzo_giocatore[i].presente = true;
		}
	//	cout<<mazzo[n_casuale2].presente<<" "<<mazzo_giocatore[i].presente<<endl;
	}
	
	//cout<<"Questo e' un debug: "<<mazzo[n_casuale].numero<<" "<<mazzo[n_casuale].tipo<<"\t"<<mazzo[n_casuale2].numero<<" "<<mazzo[n_casuale2].tipo<<endl;
}

void Briscola::calcoloPunteggio(int &p, int m, int n){
	int posizione_computer=0, posizione_giocatore=0, i=0;
	posizione_computer = n;
	posizione_giocatore = m;
	/// per il punteggio 
	if(mazzo_giocatore[posizione_giocatore].tipo == tipo_dominante && mazzo_computer[posizione_computer].tipo == tipo_dominante){
		if(mazzo_giocatore[posizione_giocatore].punteggio > mazzo_computer[posizione_computer].punteggio){
			setPunteggioGiocatore(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
			p = 1;
		}
		else{
			setPunteggioComputer(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
			p = 0;	
		}
	}
	else{
		if(mazzo_giocatore[posizione_giocatore].tipo == tipo_dominante && mazzo_computer[posizione_computer].tipo != tipo_dominante){
			setPunteggioGiocatore(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
			p = 1;
		}
		else{
			if(mazzo_giocatore[posizione_giocatore].tipo != tipo_dominante && mazzo_computer[posizione_computer].tipo == tipo_dominante){
				setPunteggioComputer(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
				p = 0;
			}
			else{
				if(mazzo_giocatore[posizione_giocatore].tipo != tipo_dominante && mazzo_computer[posizione_computer].tipo != tipo_dominante){
					if(mazzo_giocatore[posizione_giocatore].tipo == mazzo_computer[posizione_computer].tipo){
						if(mazzo_giocatore[posizione_giocatore].punteggio > mazzo_computer[posizione_computer].punteggio){
							setPunteggioGiocatore(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
							p = 1;
						}
						else{
							if(mazzo_giocatore[posizione_giocatore].punteggio == mazzo_computer[posizione_computer].punteggio){
								if(mazzo_giocatore[posizione_giocatore].numero > mazzo_computer[posizione_computer].numero){
									p = 1;
								}
								else{
									p = 0;
								}
							}
							else{
								setPunteggioComputer(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
								p = 0;	
							}
						}
					}
					else{
						if(p == 0){
							setPunteggioComputer(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
							p = 0;
						}
						else{
							setPunteggioGiocatore(mazzo_giocatore[posizione_giocatore].punteggio + mazzo_computer[posizione_computer].punteggio);
							p = 1;	
						}
					}
				}
			}	
		}
	}
}

void Briscola::stampaMazzo(void){
	cout<<"Questo e' il mazzo di gioco: "<<endl;
	for(int i=0; i < 40; i++){
		if(mazzo[i].presente == true){
			
			cout<<mazzo[i].numero<<" "<<mazzo[i].tipo<<endl;
		}	
	}
}	

bool Briscola::controlloMazzo(void){
	bool trovato = false;
	for(int i=0; i < 40; i++){
		if(mazzo[i].presente == true){
			trovato = true;
			return trovato;
		}
	}
	return trovato;
}

int Briscola::controlloMazzoGiocatore(void){
	int conta=0;
	for(int i = 0; i < 3; i++){
		if(mazzo_giocatore[i].presente == true){
			conta++;
		}
	}
	return conta;
}


void Briscola::salvataggioPartita(void){
	fstream mazzoGioco, mazzoGiocatore, mazzoComputer, filePunteggi;
	int i=0;
	
	mazzoGioco.open("File_gioco/file_mazzo.csv", ios::out);
	if(mazzoGioco.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi con il salvataggio della partita."<<endl;
	}
	for(i=0; i < 40; i++){
		if(mazzo[i].presente){
			mazzoGioco<<mazzo[i].numero<<";"<<mazzo[i].tipo<<";"<<mazzo[i].punteggio<<";"<<endl;
		}
	}
	mazzoGioco.close();
	
	mazzoGiocatore.open("File_gioco/file_giocatore.csv", ios::out);
	if(mazzoGiocatore.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi con il salvataggio della partita."<<endl;
	}
	
	mazzoComputer.open("File_gioco/file_computer.csv", ios::out);
	if(mazzoComputer.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi con il salvataggio della partita."<<endl;
	}
	
	
	for(i=0; i < 3; i++){
		mazzoGiocatore<<mazzo_giocatore[i].numero<<";"<<mazzo_giocatore[i].tipo<<";"<<mazzo_giocatore[i].punteggio<<";"<<mazzo_giocatore[i].presente<<endl;
		mazzoComputer<<mazzo_computer[i].numero<<";"<<mazzo_computer[i].tipo<<";"<<mazzo_computer[i].punteggio<<";"<<mazzo_computer[i].presente<<endl;
	}
	mazzoGiocatore.close();
	mazzoComputer.close();
	
	filePunteggi.open("File_gioco/file_punteggi.csv", ios::out);
	if(filePunteggi.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Problemi con il salvataggio dei punteggi."<<endl;
	}
	filePunteggi<<getPunteggioGiocatore()<<";"<<getPunteggioComputer()<<";"<<tipo_dominante<<";";
	filePunteggi.close();
 
}		

void Briscola::estraiElemento(void){
	int i=0, j=0, k=0;
	for(i=0; (i < DIM_MAX) && (riga[i]!='\0') && (riga[i]!=';'); i++){
	}
	for(k=0; k < i; k++){
		elemento[k] = riga[k];
	}
	elemento[k] = '\0';
	j=0;
	for(k=i+1; k < DIM_MAX; k++){
		riga[j] = riga[k];
		j++;
	}
}

void Briscola::caricamentoPartita(void){
	int conta=0, punteggio=0, k=0;
	recCarta mazzo_rimanente[40];
	fstream fileMazzo, fileGiocatore, fileComputer, filePunteggi;
	
	fileGiocatore.open("File_gioco/file_giocatore.csv", ios::in);
	if(fileGiocatore.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi nel caricamento della partita."<<endl;
	}
	while(!fileGiocatore.eof()){
		fileGiocatore.getline(riga, DIM_MAX);
		estraiElemento();
		if(elemento[0] == '1' && elemento[1] == '0'){  //da risolvere
			mazzo_giocatore[conta].numero = 10;
		}
		else{
			mazzo_giocatore[conta].numero = atoi(elemento);
		}
		estraiElemento();
		mazzo_giocatore[conta].tipo = elemento;
		estraiElemento();
		if(elemento[0] == '1' && elemento[1] == '0'){
			mazzo_giocatore[conta].punteggio = 10;
		}
		else{
			if(elemento[0] == '1' && elemento[1] == '1'){
				mazzo_giocatore[conta].punteggio = 11;
			}
			else{
				mazzo_giocatore[conta].punteggio = atoi(elemento);
			}
		}
		estraiElemento();
		if(elemento[0] == '0'){
			mazzo_giocatore[conta].presente = false;
		}
		else{
			mazzo_giocatore[conta].presente = true;
		}
		conta++;
	}
	fileGiocatore.close();
	
	conta = 0;
	fileComputer.open("File_gioco/file_computer.csv", ios::in);
	if(fileComputer.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi nel caricamento della partita."<<endl;
	}
	while(!fileComputer.eof()){
		fileComputer.getline(riga, DIM_MAX);
		estraiElemento();
		if(elemento[0] == '1' && elemento[1] == '0'){
			mazzo_computer[conta].numero = 10;
		}
		else{
			mazzo_computer[conta].numero = atoi(elemento);
		}
		estraiElemento();
		mazzo_computer[conta].tipo = elemento;
		estraiElemento();
		if(elemento[0] == '1' && elemento[1] == '0'){
			mazzo_computer[conta].punteggio = 10;
		}
		else{
			if(elemento[0] == '1' && elemento[1] == '1'){
				mazzo_computer[conta].punteggio = 11;
			}
			else{
				mazzo_computer[conta].punteggio = atoi(elemento);
			}
		}
		estraiElemento();
		if(elemento[0] == '0'){
			mazzo_computer[conta].presente = false;
		}
		else{
			mazzo_computer[conta].presente = true;
		}
		conta++;
	}
	fileComputer.close();
	
	filePunteggi.open("File_gioco/file_punteggi.csv", ios::in);
	if(filePunteggi.is_open()){
		cout<<"File aperto correttamente."<<endl;
	}
	else{
		cout<<"Problemi nel caricamento della partita."<<endl;
	}	
	filePunteggi.getline(riga, DIM_MAX);
	estraiElemento();
	punteggio = atoi(elemento);
	//cout<<"Punteggio: "<<punteggio<<endl;   debug
	setPunteggioGiocatore(punteggio);
	estraiElemento();
	punteggio = atoi(elemento);
	setPunteggioComputer(punteggio);
	estraiElemento();
	tipo_dominante = elemento;
	filePunteggi.close();
	
	fileMazzo.open("File_gioco/file_mazzo.csv", ios::in);
	if(fileMazzo.is_open()){
		cout<<"File mazzo aperto correttamente."<<endl;
	}
	else{
		cout<<"Ci sono dei problemi nel caricamento della partita."<<endl;
	}
	conta = 0;
	while(!fileMazzo.eof()){
		fileMazzo.getline(riga, DIM_MAX);
		estraiElemento();
		mazzo_rimanente[conta].numero = atoi(elemento);
		estraiElemento();
		mazzo_rimanente[conta].tipo = elemento;
		estraiElemento();
		mazzo_rimanente[conta].punteggio = atoi(elemento);
		mazzo_rimanente[conta].presente = true;
		conta++;
	}
	for(int i=0; i < conta; i++){ //scorri le carte estratte dal file 
		for(int j=k; j < 40; j++){
			if(mazzo[j].numero == mazzo_rimanente[i].numero && mazzo[j].tipo == mazzo_rimanente[i].tipo){
				mazzo[j].presente = true;
				k++;
				break;
			}
			else{
				mazzo[j].presente = false;
				k++;
			}
		}
	}
	fileMazzo.close();
	
}
