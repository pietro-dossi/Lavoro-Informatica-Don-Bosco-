//main
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <windows.h>
#include <ctime>
#include "briscola.h"
using namespace std;

int main(void){
	Briscola b;
	int mossa, priorita=0, conta_mosse_finali=3, carta_computer_tirata=0, v[3]={0}; //l'utente scrive 1 2 3
	bool pescata=false, lancio_corretto = false;  //pescata indica se � stata effettuata una pescata   
	//QUANDO PRIORITA = 0 LA HA IL COMPUTER ALTRIMENTI SE = 1 LA PRIORITA LA HA IL GIOCATORE
	////////////////////////////////////////////
	srand(time(NULL));                                                    
	b.setDominante();                                         //inizializzazione
	b.setMazzo();                                             //inizializzazione
	//b.stampaMazzo();//debug 
	cout<<endl;
	b.setMazzoComputer();                                     //inizializzazione
	b.setMazzoGiocatore();                                    //inizializzazione
	do{
		b.stampaDominante();
		cout<<endl;
		b.stampaMazzoGiocatore();
    	//b.stampaMazzoComputer(); //debug 
		if(b.controlloMazzo() == false){
			cout<<"\n\n\t\t\t\t\t\t\t\tATTENZIONE IL MAZZO E' FINITO! RIMANGONO TRE TURNI.\n"<<endl;
			 for(int i = 0; i < 3; i++){
				if(priorita == 0){
					carta_computer_tirata = b.lancioCartaComputer();
					do{                                                                                    //controllo corretto input
						cout<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]: ";
						cin>>mossa;
						for(int j=0; j < 3; j++){
							if(v[j] == mossa){
								cout<<"Errore! Hai gia' lanciato questa carta.\n"<<endl;
								lancio_corretto = false;
								break;
							}
							else{
								if(v[j] == 0){
									v[j] = mossa;
									lancio_corretto = true;
									break;
								}
							}
						}
					}while(lancio_corretto == false);					
					b.lancioCartaGiocatore(mossa);
					b.calcoloPunteggio(priorita, mossa-1, carta_computer_tirata);
					//cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
				}
				else{
					do{                                                                                        //controllo corretto input                                           
						cout<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]: ";
						cin>>mossa;
						for(int j=0; j < 3; j++){
							if(v[j] == mossa){
								cout<<"Errore! Hai gia' lanciato questa carta.\n"<<endl;
								lancio_corretto = false;
								break;
							}
							else{
								if(v[j] == 0){
									v[j] = mossa;
									lancio_corretto = true;
									break;
								}
							}
						}
					}while(lancio_corretto == false);
					b.lancioCartaGiocatore(mossa);
					carta_computer_tirata = b.lancioCartaComputer();
					b.calcoloPunteggio(priorita, mossa-1, carta_computer_tirata);
					//cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
				}
			}
	    	//b.calcoloPunteggio(priorita, mossa-1, carta_computer_tirata); //debug, il ciclo all'ultimo giro non calcolava il punteggio.
			pescata = false;
		}
		else{	
			cout<<endl;
			if(priorita == 0){
				carta_computer_tirata = b.lancioCartaComputer();
				do{                                                                                         //controllo input corretto
					cout<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]: ";
					cin>>mossa;
					if(mossa < 1 || mossa > 3){
						cout<<"Errore! Devi inserire [1, 2, o 3]."<<endl;
					}
				}while(mossa < 1 || mossa > 3);
				
				b.lancioCartaGiocatore(mossa);
				b.calcoloPunteggio(priorita, mossa-1, carta_computer_tirata);
				//cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
				if(b.controlloMazzo()){
					b.pescaCarta();
					//b.stampaMazzo();
					pescata = true;
				}
				/*else{
					cout<<"Tutte le carte sono false."<<endl;                                             //debug
				}*/
				
				cout<<"////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////\n\n\n\n\n"<<endl;
			}
			else{
				do{                                                                                       //controllo input corretto
					cout<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]: ";
					cin>>mossa;
					if(mossa < 1 || mossa > 3){
						cout<<"Errore! Devi inserire [1, 2, o 3]."<<endl;
					}
				}while(mossa < 1 || mossa > 3);
				b.lancioCartaGiocatore(mossa);
				carta_computer_tirata = b.lancioCartaComputer();
				cout<<endl;
				b.calcoloPunteggio(priorita, mossa-1, carta_computer_tirata);
				//cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
				if(b.controlloMazzo()){
					b.pescaCarta();
					//b.stampaMazzo();
					pescata = true;
				}
				
				cout<<"////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////\n\n\n\n\n\n\n\n"<<endl;
			}
		}
		Sleep(1000);
		cout<<endl;
	}while(pescata);
	cout<<"\nSto calcolando il punteggio e decretando il vincitore..."<<endl;
	Sleep(2000);
	if(b.getPunteggioComputer() > b.getPunteggioGiocatore()){
		cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
		cout<<"\nIL VINCITORE DELLA PARTITA E' IL COMPUTER."<<endl;
	}
	else{
		cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
		cout<<"\nIL VINCITORE DELLA PARTITA SEI TU."<<endl;
	} 
	cout<<endl;
	//b.stampaMazzo();//debug 
	cout<<endl;
	system("PAUSE");
	
}
