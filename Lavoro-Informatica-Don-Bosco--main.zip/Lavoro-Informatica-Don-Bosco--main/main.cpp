//main
#include <iostream>
#include <cstring>
#include <cstdlib>
#include <ctime>
#include "briscola.h"
using namespace std;

int main(void){
	Briscola b;
	int mossa, priorita=0; //l'utente scrive 1 2 3
	bool pescata=false;  //pescata indica se � stata effettuata una pescata   
	//QUANDO PRIORITA = 0 LA HA IL COMPUTER ALTRIMENTI SE = 1 LA PRIORITA LA HA IL GIOCATORE
	////////////////////////////////////////////
	srand(time(NULL));
	b.setDominante();
	b.setMazzo();
	b.stampaMazzo();//debug 
	cout<<endl;
	b.setMazzoComputer();
	b.setMazzoGiocatore();
	do{
		b.stampaDominante();
		cout<<endl;
		b.stampaMazzoGiocatore();
		b.stampaMazzoComputer(); //debug 
		pescata = false;
		cout<<endl;
		if(priorita == 0){
			b.lancioCartaComputer();
			cout<<endl<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]."<<endl;
			cin>>mossa;
			b.lancioCartaGiocatore(mossa);
			b.calcoloPunteggio(priorita);
			if(b.controlloMazzo()){
				b.pescaCarta();
				b.stampaMazzo();
				pescata = true;
			}
			
			cout<<"///////////////////////////////////////////////////////////////////////////////////////////////\n\n\n\n\n"<<endl;
		}
		else{
			cout<<"Fai la tua mossa. Scegli la carta da lanciare. Digita [1, 2, o 3]."<<endl;
			cin>>mossa;
			b.lancioCartaGiocatore(mossa);
			b.lancioCartaComputer();
			b.calcoloPunteggio(priorita);
			if(b.controlloMazzo()){
				b.pescaCarta();
				b.stampaMazzo();
				pescata = true;
			}
			
			cout<<"///////////////////////////////////////////////////////////////////////////////////////////////\n\n\n\n\n\n\n\n"<<endl;
		}
	}while(pescata == true);
	if(b.getPunteggioComputer() > b.getPunteggioGiocatore()){
		cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
		cout<<"Il vincitore della partita e' il tuo avversario."<<endl;
	}
	else{
		cout<<"Punteggio avversario: "<<b.getPunteggioComputer()<<endl<<"Punteggio personale: "<<b.getPunteggioGiocatore()<<endl;
		cout<<"Il vincitore della partita sei tu."<<endl;
	} 
	cout<<endl;
	b.stampaMazzo();//debug 
	cout<<endl;
	system("PAUSE");
	
}
