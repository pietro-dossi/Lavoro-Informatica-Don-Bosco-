//Dossi Pietro e Patuzzo Mattia
//documento per le note.

/*
carte totali 40; 
per le carte (numeri e tipi) usiamo una struct 
struct carte{
	int numero_carta;
	string tipo;
	bool presente;   serve per verificare la disponibilt� di una carta.
}
due variabili punti per i giocatori
una variabile per il tipo di carta dominante 


inizio partita stampa delle carte del giocatore
sostituzione della carta selezionata con quella nuova pescata dal mazzo.



per spade cout<<"_____________"<<endl<<"|	          |"<<endl<<"|	   .      |"<<endl<<"|	  / \\     |"<<endl<<"|	  | |     |"<<endl<<"|	  | |     |"<<endl<<"|	  |:|     |"<<endl<<"|	`--8--'   |"<<endl<<"|	   8      |"<<endl<<"|	   0      |"<<endl<<"|_____________|"<<endl;
per bastoni cout<<" ____"<<endl<<"|             |"<<endl<<"|      mazzo_giocatore[i].numero      |"<<endl<<"|   bastoni   |"<<endl<<"|      .      |"<<endl<<"|     / \\     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     | |     |"<<endl<<"|     \\ /     |"<<endl<<"|      .      |"<<endl<<"|____|"<<endl;
*/

/*









					 
				 _____________	 
				|	          |    
				|	   .      |
				|	  / \     |
				|	  | |     |
				|	  | |     |
				|	  |:|     |
				|	`--8--'   |
				|	   8      |
				|	   O      |
				|_____________|




				 _____________                _____________	   
				|	          |              |             |
				|	   .      |              |      _      | 
				|	  / \     | 			 |     / \     |
				|	  | |     |              |     \ /     |
				|	  | |     |              |     | |     |
				|	  | | 	  |              |     | |     |
				|	  | |     |              |     | |     |
     			|     \ /     |	             |     / \     |
				|      .      |              |     \_/     |
				|_____________|              |_____________|
				
*/
